from subprocess import call
import winsound
# have fun :)

#Open 2
def open_py_file():
    call(["python", "DONOTOPENME.py"])

open_py_file()

# Audio
winsound.PlaySound("music", winsound.SND_FILENAME)






