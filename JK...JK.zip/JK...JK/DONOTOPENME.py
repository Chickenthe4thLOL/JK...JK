import os

# lol 
for i in range(1729):
    os.startfile("cmd.exe") 
